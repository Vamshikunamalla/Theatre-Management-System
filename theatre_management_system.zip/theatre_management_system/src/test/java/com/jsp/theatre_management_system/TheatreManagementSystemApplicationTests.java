package com.jsp.theatre_management_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheatreManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
